package com.example.witherrosecollector.mixin;

import com.example.witherrosecollector.WitherRoseCollectorMod;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    @Shadow public abstract float getYaw();
    @Shadow public abstract void setYaw(float yaw);
    @Shadow public abstract boolean isSprinting();
    @Shadow public abstract void setSprinting(boolean sprinting);

    @Inject(method = "tick()V", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (!WitherRoseCollectorMod.isWalking()) {
            if (player.isSprinting()) player.setSprinting(false);
            return;
        }

        BlockPos flower = WitherRoseCollectorMod.getTargetFlower();
        Vec3d playerPos = player.getPos();
        Vec3d targetVec = new Vec3d(flower.getX() + 0.5, flower.getY(), flower.getZ() + 0.5);
        double dx = targetVec.x - playerPos.x;
        double dz = targetVec.z - playerPos.z;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);

        if (horizontalDist <= WitherRoseCollectorMod.getInteractDistance()) {
            WitherRoseCollectorMod.onReachedTarget(player);
            return;
        }

        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float yaw = targetYaw;

        if (player.horizontalSpeed < 0.01f && player.isOnGround()) {
            WitherRoseCollectorMod.addStuckTick();
        } else {
            WitherRoseCollectorMod.resetStuckTicks();
        }

        if (WitherRoseCollectorMod.shouldEvasiveTurn()) {
            yaw += 45.0f;
        }

        setYaw(yaw);
        player.prevYaw = yaw;

        var input = ((ClientPlayerEntityAccessor) player).getInput();
        input.movementForward = 1.0f;
        input.movementSideways = 0.0f;

        player.setSprinting(true);

        if (player.horizontalSpeed < 0.01f && player.isOnGround() && player.age % 5 == 0) {
            input.jumping = true;
        } else {
            input.jumping = false;
        }
    }
}
