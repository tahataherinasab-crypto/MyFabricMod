package com.example.witherrosecollector.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ClientPlayerEntity.class)
public interface ClientPlayerEntityAccessor {
    @Accessor("input")
    Input getInput();
}
