package com.example.witherrosecollector;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WitherRoseCollectorMod implements ClientModInitializer {
    public static final String MOD_ID = "witherrosecollector";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static boolean enabled = false;
    private static boolean paused = false;
    private static boolean autoWalking = false;
    private static BlockPos targetFlower = null;
    private static int cooldownTicks = 0;
    private static int countdownTicks = 0;
    private static int stuckTicks = 0;

    private static final int COOLDOWN_SECONDS = 5;
    private static final int SCAN_RADIUS = 50;
    private static final int INTERACT_DISTANCE = 2;
    private static final int STUCK_THRESHOLD = 10;
    private static final int COUNTDOWN_SECONDS = 10;

    public static boolean isWalking() {
        return enabled && !paused && autoWalking && targetFlower != null;
    }
    public static BlockPos getTargetFlower() { return targetFlower; }
    public static int getInteractDistance() { return INTERACT_DISTANCE; }

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            var cmd = ClientCommandManager.literal("wither-rose-mod");

            dispatcher.register(cmd
                .then(ClientCommandManager.literal("start").executes(ctx -> { start(); return 1; }))
                .then(ClientCommandManager.literal("stop").executes(ctx -> { stop(); return 1; }))
                .then(ClientCommandManager.literal("run").executes(ctx -> { run(); return 1; }))
                .then(ClientCommandManager.literal("cancel").executes(ctx -> { cancel(); return 1; }))
            );
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            if (!enabled) return;
            if (paused) return;

            if (autoWalking) {
                if (targetFlower != null && !client.world.getBlockState(targetFlower).isOf(Blocks.WITHER_ROSE)) {
                    autoWalking = false;
                    targetFlower = null;
                }
                return;
            }

            if (countdownTicks > 0) {
                countdownTicks--;
                if (countdownTicks % 20 == 0 && countdownTicks > 0) {
                    int sec = countdownTicks / 20;
                    client.player.sendMessage(Text.literal("§cخاموشی خودکار تا §e" + sec + " §cثانیه دیگر..."), true);
                }
                if (countdownTicks == 0) {
                    cancel(true);
                }
                return;
            }

            if (cooldownTicks > 0) {
                cooldownTicks--;
                return;
            }

            BlockPos nearest = findNearestWitherRose(client);
            if (nearest != null) {
                targetFlower = nearest;
                autoWalking = true;
                stuckTicks = 0;
                client.player.sendMessage(Text.literal("§aدر حال حرکت به سمت Wither Rose..."), false);
            } else {
                countdownTicks = COUNTDOWN_SECONDS * 20;
                client.player.sendMessage(Text.literal("§cویدر رز پیدا نشد. خاموشی خودکار تا " + COUNTDOWN_SECONDS + " ثانیه..."), false);
            }
        });
    }

    private BlockPos findNearestWitherRose(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        World world = client.world;
        BlockPos playerPos = player.getBlockPos();
        BlockPos nearest = null;
        double nearestDistSq = Double.MAX_VALUE;

        for (int x = -SCAN_RADIUS; x <= SCAN_RADIUS; x++) {
            for (int z = -SCAN_RADIUS; z <= SCAN_RADIUS; z++) {
                if (x * x + z * z > SCAN_RADIUS * SCAN_RADIUS) continue;
                int chunkX = (playerPos.getX() + x) >> 4;
                int chunkZ = (playerPos.getZ() + z) >> 4;
                if (!world.isChunkLoaded(chunkX, chunkZ)) continue;

                for (int y = -2; y <= 2; y++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    if (world.getBlockState(pos).isOf(Blocks.WITHER_ROSE)) {
                        double distSq = playerPos.getSquaredDistance(pos);
                        if (distSq < nearestDistSq) {
                            nearestDistSq = distSq;
                            nearest = pos;
                        }
                    }
                }
            }
        }
        return nearest;
    }

    public static void onReachedTarget(ClientPlayerEntity player) {
        if (targetFlower == null || !autoWalking) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.interactionManager == null) return;

        BlockHitResult hit = new BlockHitResult(
            new Vec3d(targetFlower.getX() + 0.5, targetFlower.getY() + 1.0, targetFlower.getZ() + 0.5),
            Direction.UP, targetFlower, false
        );
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        player.swingHand(Hand.MAIN_HAND);
        player.setSprinting(false);

        player.sendMessage(Text.literal("§eکلیک روی Wither Rose انجام شد."), false);

        autoWalking = false;
        targetFlower = null;
        cooldownTicks = COOLDOWN_SECONDS * 20;
        stuckTicks = 0;
    }

    public static void addStuckTick() { stuckTicks++; }
    public static boolean shouldEvasiveTurn() { return stuckTicks > STUCK_THRESHOLD; }
    public static void resetStuckTicks() { stuckTicks = 0; }

    private static void start() {
        enabled = true;
        paused = false;
        autoWalking = false;
        targetFlower = null;
        cooldownTicks = 0;
        countdownTicks = 0;
        stuckTicks = 0;
        MinecraftClient.getInstance().player.sendMessage(Text.literal("§aماد شروع به کار کرد"), false);
    }

    private static void stop() {
        if (!enabled) return;
        paused = true;
        autoWalking = false;
        targetFlower = null;
        cooldownTicks = 0;
        var player = MinecraftClient.getInstance().player;
        if (player != null) player.setSprinting(false);
        player.sendMessage(Text.literal("§fماد استوپ شد"), false);
    }

    private static void run() {
        if (!enabled || !paused) return;
        paused = false;
        autoWalking = false;
        MinecraftClient.getInstance().player.sendMessage(Text.literal("§aماد راه اندازی مجدد شد"), false);
    }

    private static void cancel() { cancel(false); }

    private static void cancel(boolean auto) {
        enabled = false;
        paused = false;
        autoWalking = false;
        targetFlower = null;
        cooldownTicks = 0;
        countdownTicks = 0;
        stuckTicks = 0;
        var player = MinecraftClient.getInstance().player;
        if (player != null) {
            player.setSprinting(false);
            String msg = auto ? "§cماد به دلیل پیدا نکردن ویدر رز به صورت اتوماتیک خاموش شد" : "§cماد خاموش شد";
            player.sendMessage(Text.literal(msg), false);
        }
    }
}
